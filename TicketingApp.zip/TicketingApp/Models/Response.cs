﻿namespace TicketingApp.Models
{
    public class Response
    {
        public string ErrorMessage { get; set; }
    }
}
